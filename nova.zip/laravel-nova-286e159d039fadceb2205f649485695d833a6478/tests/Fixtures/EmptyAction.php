<?php

namespace Laravel\Nova\Tests\Fixtures;

use Laravel\Nova\Actions\Action;

class EmptyAction extends Action
{
    //
}
