<?php

namespace Laravel\Nova\Fields;

class Avatar extends Image
{
    //
}
