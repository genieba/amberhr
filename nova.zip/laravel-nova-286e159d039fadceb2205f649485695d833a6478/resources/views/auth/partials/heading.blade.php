<h2 class="text-2xl text-center font-normal mb-6 text-90">{{ $slot }}</h2>
<svg class="block mx-auto mb-6" xmlns="http://www.w3.org/2000/svg" width="100" height="2" viewBox="0 0 100 2"><g id="Page-1" fill="none" fill-rule="evenodd"><g id="08-login" fill="#D8E3EC" transform="translate(-650 -371)"><path id="Rectangle-15" d="M650 371h100v2H650z"/></g></g></svg>
