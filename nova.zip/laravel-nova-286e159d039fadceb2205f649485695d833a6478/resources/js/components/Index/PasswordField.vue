<template>
    <span class="font-bold">
        &middot;
        &middot;
        &middot;
        &middot;
        &middot;
        &middot;
        &middot;
        &middot;
    </span>
</template>

<script>
export default {
    props: ['resourceName', 'field'],
}
</script>
