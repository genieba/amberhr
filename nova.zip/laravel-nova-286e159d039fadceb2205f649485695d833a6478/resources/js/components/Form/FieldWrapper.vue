<template functional>
    <div class="flex border-b border-40">
        <slot />
    </div>
</template>
